close all; clc; clear;
% parameters
size = 50;
features = 3;
eta = 0.8;

X = create_random_input(size, features);

figure();
hold on;
for i = 1:length(X)
    if X(i,features+1) == 1
        plot3(X(i,1),X(i,2),X(i,3),'*b')
    else
        plot3(X(i,1),X(i,2),X(i,3),'or')
    end
end
title('Input samples');

sigmoid = @(x) 1./(1+exp(-x));
dsigmoid = @(x) exp(-x)/((1+exp(-x))^.2);
% j = @(x )1/2*x^2;

% initialise W randomlY
W = rand(3,1);

% initial calculation of Y, and cost function based on Y.
Y = sigmoid(X(:,1:3)*W);
E = X(:,4) - Y;
J = 1/2*E'*E;

% as long as J is decreasing, continue operation
J_old = J;
W_old = W;
J_vector = J;
while true
    W = W_old+eta*(X(:,1:3)'*E);
    Y = sigmoid(X(:,1:3)*W);
    E = X(:,4) - Y;
    J = 1/2*E'*E;
    J_vector = [J_vector, J];
    if J_old == J;
        break
    end
    J_old = J;
    W_old = W;
end
funcplane = @(x,y) -(W(1)/W(3))*x -(W(2)/W(3))*y;
ezsurf(funcplane,[-5 5],[-5 5],2);
xlim([-10 10]);
ylim([-10 10]);
zlim([-10 10]);
view([45,30])
figure()
plot(J_vector(1:end-1))
