close all; clc; clear;

[A2,a2] = create_number(2,8);
[A3,a1] = create_number(1,8);
[A4,a4] = create_number(4,8);
[A7,a7] = create_number(7,8);
[A9,a9] = create_number(9,8);

list{1} = a2;
list{2} = a1;
list{3} = a4;
list{4} = a7;
list{5} = a9;

T = zeros(64);
for j=1:64
    for k=1:64
        temp = 0;
        for i=1:5
            if j~=k
                temp = temp + list{i}(j)*list{i}(k);
            end
        end
        if j~=k
           T(j,k) = temp; 
        end
    end
end

B = sign(randn(8));
b = reshape(B, [64,1]);

old = b;
iteration = 0;
while true
    iteration = iteration + 1;
    current = sign(T*old);
    if current == old
        break
    end
    old = current;
end

B_new = reshape(current, [8,8]);

imshow(B,'InitialMagnification', 'fit')
figure(2)
imshow(B_new,'InitialMagnification', 'fit')

    
