function [B, b] = create_random_input(size, sigma)

B = sign(sigma*randn(size));
b = reshape(B, [size*size,1]);