function [T] = create_T_matrix(list)

% creation of T matrix based on input patterns
T = zeros(64);
for j=1:64
    for k=1:64
        temp = 0;
        for i=1:5
            if j~=k
                temp = temp + list{i}(j)*list{i}(k);
            end
        end
        if j~=k
           T(j,k) = temp; 
        end
    end
end
    
