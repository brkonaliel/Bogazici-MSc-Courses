close all; clc; clear;

% Input patterns: "A" represent matrix form, "a" represent vector form.
% Numbers are what the matrix and vector represent.
[A2,a2] = create_number(2,8);
[A1,a1] = create_number(1,8);
[A4,a4] = create_number(4,8);
[A7,a7] = create_number(7,8);
[A9,a9] = create_number(9,8);

% Input pattern vectors are stored in a list
list{1} = a2;
list{2} = a1;
list{3} = a4;
list{4} = a7;
list{5} = a9;

figure()
subplot(1,5,1), subimage(A2)
title(['Input Pattern ', '2'])
subplot(1,5,2), subimage(A1)
title(['Input Pattern ', '1'])
subplot(1,5,3), subimage(A4)
title(['Input Pattern ', '4'])
subplot(1,5,4), subimage(A7)
title(['Input Pattern ', '7'])
subplot(1,5,5), subimage(A9)
title(['Input Pattern ', '9'])

% Creation of T matrix based on the list described above.
T = create_T_matrix(list);

% Creation of random input to the NN with sigma values 1,2,3. Each created
% vector is fed to NN and iterated till convergence to one of the input
% patterns.

for sigma=1:3
    [B, b] = create_random_input(8, sigma);
    old = b;
    iteration = 0;
    while true
        iteration = iteration + 1;
        current = sign(T*old);
        if current == old
            break
        end
        old = current;
    end
    B_new = reshape(current, [8,8]);
    
    figure()
    sigma_title = int2str(sigma);
    subplot(1,2,1), subimage(B)
    title(['Random Input with standart deviation ', sigma_title]) 
    subplot(1,2,2), subimage(B_new)
    title('Convergence Pattern')
end

